import pandas as pd
from matplotlib import pyplot as plt
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix
import tensorflow.keras.Sequential as Sequential
import numpy as np

df = pd.read_csv('diabetes.csv')
df.loc[df['class']=='tested_positive','class'] = 1
df.loc[df['class']=='tested_negative','class'] = 0
tmpClass = df['class']
df = df.drop(['class'], axis=1)
x = df.values
minMaxScaler = preprocessing.MinMaxScaler()
x_scaled = preprocessing.MinMaxScaler().fit_transform(x)
df = pd.DataFrame(x_scaled)
df['class'] = tmpClass
print(df)

# allInputs = df[[0, 1, 2, 3]].values
# allClasses = df[['virginica', 'versicolor', 'setosa']].values
# (trainInputs, testInputs, trainClasses, testClasses) = train_test_split(allInputs, allClasses, train_size=0.7, random_state=1)

# model = Sequential()
# model.add(Dense(32, input_dim=4, activation='relu'))
# model.add(Dense(16,activation='relu'))
# model.add(Dense(9,activation='relu'))
# model.add(Dense(3, activation='softmax'))
# model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
# history = model.fit(trainInputs, trainClasses, epochs=100, batch_size=64)

# y_pred = model.predict(testInputs)
# pred = list()
# for i in range(len(y_pred)):
#     pred.append(np.argmax(y_pred[i]))
# test = list()
# for i in range(len(testClasses)):
#     test.append(np.argmax(testClasses[i]))
# a = accuracy_score(pred,test)
# print(confusion_matrix(pred, test))
# print('Accuracy:', a*100, '%')